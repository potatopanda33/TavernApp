import 'package:flutter/material.dart';
import './preset_web.dart';


void main() => runApp(WebApp(null, false, false));
